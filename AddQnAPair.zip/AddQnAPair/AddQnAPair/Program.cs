﻿using System;
using System.Net.Http.Headers;
using System.Text;
using System.Net.Http;
using System.Web;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace CSHttpClientSample
{
    public static class HttpClientExtensions
    {
        public static async Task<HttpResponseMessage> PatchAsync(this HttpClient client, Uri requestUri, HttpContent iContent)
        {
            var method = new HttpMethod("PATCH");
            var request = new HttpRequestMessage(method, requestUri)
            {
                Content = iContent
            };

            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                response = await client.SendAsync(request);
            }
            catch (TaskCanceledException e)
            {
                Console.WriteLine("ERROR: " + e.ToString());
            }

            return response;
        }
    }
    
    static class Program
    {
        static void Main()
        {
            MakeRequest();
            Console.WriteLine("Hit ENTER to exit...");
            Console.ReadLine();
        }

        static async void MakeRequest()
        {
            var client = new HttpClient();
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "<Subscription key>");
            
            #region Payload
            string jsonstring = @"
                {
                    'add': {
                        'qnaList': [
        	                {
                                'questions': ['Hola'],
                                'answer': 'howdy, How can I help you?',
                                'metadata': [
                	                {
                		                'name' : 'category',
                		                'value': 'chit-chat'
                	                }
                	                ]
                            }],
                        'urls': [],
                        'users': []
                    },
                    'delete': {
                        'qnaIds': [7, 8],
                        'sources': [
                            'Editorial'
                        ],
                        'users':[]
                    },
                    'update': {
    	                'qnaList' : [{
    			                'qnaId' : 1,
    			                'answer': 'Please ask your questions for details.',
    			                'source': '1f1cf58c-2aee-4634-959d-237b6405f953-KB.tsv',
    			                'questions' : {
    				                'add': ['hey'],
    				                'delete': ['hi']
    			                },
    			                'metadata': {
    				                'add': [{'name':'category', 'value':'chit-chat'}]
    	                }
    	                }
    	                ],
    	                'urls': []
                    }
                }";

            #endregion

            HttpContent httpContent = new StringContent(jsonstring, Encoding.UTF8, "application/json");
            
            var uri = @"https://westus.api.cognitive.microsoft.com/qnamaker/v3.0/knowledgebases/<KnowledgebaseID>";
            Uri QnAUri = new Uri(uri);
            HttpResponseMessage hrm = await client.PatchAsync(QnAUri, httpContent);
            Console.WriteLine("HRM Status code : " + hrm.StatusCode);
            Console.WriteLine("HRM Content : " + hrm.Content.ToString());
        }
    }
}
